<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0C041C">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Darul Ulum - Media Pembelajaran Bahasa Arab</title>

    <link rel="icon" href="<?php echo e(asset('img/baru.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>


</head>

<body>

    <!-- start preloader -->
    <div class="preloader" id="preloader"></div>

    <!-- header-section start -->
    <!-- header-section end -->

    <section id="checkout" class="pt-120 pb-120 text-sm">

        <div class="overlay">
            <div class="row" style="justify-content: center;
        align-items: center; margin-top: 20px;">
                <form class="col-lg-10 " method="POST" action="<?php echo e(route('quiz.submit', ['id' => $quiz->id])); ?>" style="background: #0c040f; margin-right: 20px;
    margin-left: 20px;
    border: 3px solid rgb(165 57 171 / 20%);
    border-radius: 0px;
    padding: 30px 20px;
    margin-bottom: 40px;    
    margin-top: 20px;">
                    <?php echo csrf_field(); ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="head-area top" style="margin-bottom: 0px;">
                                    <div class="payment-container billing question q">
                                        <div class="head-area">
                                            <div class="row">
                                                <div class="col text-sm">
                                                    <h5 style="font-weight: bold;">Jawaban Telah di Rekam
                                                    </h5>
                                                   
                                                    

                                                </div>
                                                
                                            </div>

                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="payment-container">
                                    <div class="row">
                                        <div class="col" style="text-align: right;">
                                            <button type="submit" class="cmn-btn btn-sm float-right"
                                                style="color: #fff; margin-top: 0px;">Lihat Jawaban</button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
            </div>
            </form>
        </div>
        </div>
    </section>
    <!-- footer-section start -->
    <!-- footer-section end -->

    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slick.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fontawesome.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\DELL\Pictures\Laporan Akhir\Darul_Ulum\resources\views/siswa/rekam-kuis.blade.php ENDPATH**/ ?>