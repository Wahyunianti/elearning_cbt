<?php if(session('berhasil')): ?>
<div id="success-alert" style="padding-left: 0px; padding-right: 0px; margin-bottom: 10px;text-align:center; background-color: #14051d; color: #81407d; border: 1px solid #81407d; z-index: 2000;" class="alert alert-success alert-dismissable fade show">
    <i class="far fa-check-circle"></i> <?php echo e(session('berhasil')); ?>

</div>
<?php endif; ?>

<?php if(session('warning')): ?>
<div id="warning-alert" class="alert alert-warning alert-dismissable fade show">
    <i class="bi bi-exclamation-triangle"></i> <?php echo e(session('warning')); ?>

</div>
<?php endif; ?> 

<?php if($errors->any()): ?>
<div id="errorO-alert" style="padding-left: 0px; padding-right: 0px; margin-bottom: 10px;text-align:center; background-color: #14051d; color: #81407d; border: 1px solid #81407d; z-index: 2000;" class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-triangle" ></i>
    <strong >Gagal !</strong>
    <ul>
        <div class="row justify-content-center" style="margin-top:3px;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-12" style="margin-bottom: 10px">
                <li style="color: #81407d;"><?php echo e($pesan); ?></li>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </ul>   
</div>
<?php endif; ?>

<script>
    setTimeout(function() {
        var successAlert = document.getElementById('success-alert');
        if (successAlert) {
            successAlert.style.display = 'none';
        }

        var warningAlert = document.getElementById('warning-alert');
        if (warningAlert) {
            warningAlert.style.display = 'none';
        }

        var errorlo = document.getElementById('errorO-alert');
        if (errorlo) {
            errorlo.style.display = 'none';
        }
    }, 5000);
</script>
<?php /**PATH C:\Users\DELL\Pictures\Laporan Akhir\Darul_Ulum\resources\views/layouts/alert-flash-message.blade.php ENDPATH**/ ?>