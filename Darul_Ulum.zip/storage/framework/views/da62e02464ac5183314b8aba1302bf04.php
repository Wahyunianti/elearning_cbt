<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0C041C">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Darul Ulum - Media Pembelajaran Bahasa Arab</title>

    <link rel="icon" href="<?php echo e(asset('img/baru.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>


</head>

<body>

    <!-- start preloader -->
    <div class="preloader" id="preloader"></div>

    <!-- header-section start -->
    <!-- header-section end -->


    <div data-push data-responsive-width="992px" class="mdk-drawer-layout js-mdk-drawer-layout">
<div class="mdk-drawer-layout__content page ">

   <form action="<?php echo e(route('quiz.submit', ['id' => $quiz->id])); ?>">

    <div class="container-fluid page__container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="fixed-student-dashboard.html">Home</a></li>
            <li class="breadcrumb-item active">Quiz</li>
        </ol>
 
        <div class="card-group">
            <button type="submit" class="btn btn-primary float-right">Submit Now</button>
 
        </div>
 
        <div class="card">

             <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 
             <div class="question q<?php echo e(++$loop->index); ?>" style="display: none">
 
                 <div class="card-header">
                     <div class="media align-items-center">
                         <div class="media-left">
                             <h4 class="mb-0"><strong>#<?php echo e($loop->index); ?></strong></h4>
                         </div>
                         <div class="media-body">
                             <h4 class="card-title">
                                 <?php echo e($question->question); ?>

                             </h4>
                         </div>
                     </div>
                 </div>
     
                 <div class="card-body">
     
                     <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     
                     <div class="form-group">
                         <div class="custom-control custom-radio">
                             <input id="<?php echo e($option); ?>"
                                    type="radio"
                                    value="<?php echo e($key); ?>"
                                    name="<?php echo e($question->id); ?>"
                                    class="custom-control-input">
                             <label for="<?php echo e($option); ?>"
                                    class="custom-control-label">(<?php echo e(Str::lower($key)); ?>) <?php echo e($option); ?></label>
                         </div>
                     </div>
                         
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                 
                 </div>            
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            <div class="card-footer">
                <button type="button" class="btn btn-primary float-left" id="prevBtn">previous <i class="material-icons btn__icon--left">send</i></button>
                <button type="button" class="btn btn-primary float-right" id="nextBtn">Next <i class="material-icons btn__icon--right">send</i></button>
            </div>
        </div>
    </div>
   </form>

</div>

<div class="mdk-drawer js-mdk-drawer" data-align="end">
   <div class="mdk-drawer__content ">
       <div class="sidebar sidebar-right sidebar-light bg-white o-hidden"
            data-perfect-scrollbar>
           <div class="sidebar-p-y">
               <div id="countdown" class="countdown sidebar-p-x"
                    data-value="<?php echo e($quiz->duration); ?>"
                    data-unit="minutes"></div>              
           </div>

       </div>

   </div>
</div>

</div>

<script>

    let currentQuestion = "q1";

    const nextBtn = document.getElementById('nextBtn');
    const prevBtn = document.getElementById('prevBtn');
    const allQuestions = document.querySelectorAll('.question');
    const totalQuestions = allQuestions.length;

    sessionStorage.setItem('question', currentQuestion);
    prevBtn.style.display = 'none';


    document.querySelector(`.${currentQuestion}`).style.display = "block";

    nextBtn.addEventListener('click', () => {

        let que = sessionStorage.getItem('question');
        let next = que.substring(1, que.length);

        next = next * 1 + 1;

        if(next == totalQuestions) {
            nextBtn.style.display = 'none';
        }

        sessionStorage.setItem('question', `q${next}`);
        next = sessionStorage.getItem('question')

        prevBtn.style.display = 'block';

        document.querySelector(`.${next}`).style.display = "block";
        document.querySelector(`.${que}`).style.display = "none";

    });

    prevBtn.addEventListener('click', () => {
        
        let que = sessionStorage.getItem('question');
        let next = que.substring(1, que.length);

        next = next * 1 - 1;

        if(next == 1) {
            prevBtn.style.display = 'none';
            nextBtn.style.display = 'block';
        }

        nextBtn.style.display = 'block';

        sessionStorage.setItem('question', `q${next}`);
        next = sessionStorage.getItem('question')

        document.querySelector(`.${next}`).style.display = "block";
        document.querySelector(`.${que}`).style.display = "none";

    });



</script>

<script>
    // Mendapatkan elemen countdown
    var countdownElement = document.getElementById('countdown');

    // Mendapatkan nilai waktu dari atribut data
    var countdownValue = countdownElement.getAttribute('data-value');

    // Menghitung waktu akhir berdasarkan nilai waktu
    var endTime = new Date();
    endTime.setSeconds(endTime.getSeconds() + parseInt(countdownValue) * 60); // Menambahkan menit ke waktu sekarang

    // Fungsi untuk memperbarui hitungan mundur setiap detik
    function updateCountdown() {
        var now = new Date();
        var distance = endTime - now;

        // Menghitung menit dan detik dari selisih waktu
        var minutes = Math.floor(distance / (1000 * 60));
        var seconds = Math.floor((distance % (1000 * 60)) / 1000);

        // Format waktu dengan menambahkan nol di depan jika nilai kurang dari 10
        var formattedMinutes = minutes < 10 ? "0" + minutes : minutes;
        var formattedSeconds = seconds < 10 ? "0" + seconds : seconds;

        // Menampilkan waktu dalam elemen countdown
        countdownElement.innerHTML = formattedMinutes + ":" + formattedSeconds;

        // Jika hitungan mundur selesai
        if (distance < 0) {
            clearInterval(interval);
            countdownElement.innerHTML = "00:00";
            // Menampilkan alert waktu habis
            alert("Waktu sudah habis!");
            // Menyimpan URL tujuan
            var destinationUrl = "shopee.com"; // Ganti dengan URL tujuan Anda
            // Mengarahkan pengguna ke halaman tujuan setelah alert diklik "OK"
            window.location.href = destinationUrl;
            // Lakukan tindakan setelah waktu habis di sini
        }
    }

    // Memanggil fungsi updateCountdown setiap detik
    var interval = setInterval(updateCountdown, 1000);
</script>



    <!-- footer-section start -->


    <!-- footer-section end -->

    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slick.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fontawesome.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\DELL\Pictures\Laporan Akhir\Darul_Ulum\resources\views/siswa/startkuis.blade.php ENDPATH**/ ?>