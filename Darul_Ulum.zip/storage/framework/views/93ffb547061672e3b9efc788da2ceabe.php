

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="banner-section" style="background: #1a052a;
    padding-bottom: 0px;
    padding-top: 80px;
" class="inner-banner profile features shop">
    <div class="banner-content d-flex align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="main-content">
                        <div class="breadcrumb-area">
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb d-flex justify-content-center">
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section id="shop-cart-section" class="pt-120 pb-120">
        <div class="overlay">
            <div class="container">
            <div class="shop-cart-top" style="background-color: #2e1440;">
                <div class="row"  style="margin-top: 15px;">
                <div class="col-lg-12">
                <div class="shop-cart-top" style="background-color: #14051d;">
                        <div class="row align-items-center">
                            <div class="col-sm-8" style="padding-bottom: 10px;">
                                <div class="shop-cart-left">
                                    <p class="text-sm" style="font-size: 15px; color: #fff; font-weight: bold;">Bab <?php echo e($dataInfo->bab); ?> - <?php echo e($dataInfo->nama); ?> Kelas <?php echo e($kls); ?></p>
                                </div>
                            </div>                            
                        </div>
                        <hr style="border-top: 1px solid #683678">
                        <div class="col" style="margin-top: 10px; color: #fff; font-size: 14px;">
                        <div class="row align-items-center">
                        <input type="hidden" id="idKey" name="idKey" value="<?php echo e($id); ?>">
                        <p class="text-sm" style="font-size: 15px; color: #8e5f9d; text-align: left;">Keterangan : <?php echo e($dataInfo->keterangan); ?></p>
                            </div>
                            <div class="row align-items-center">
                        <p class="text-sm" style="font-size: 15px; color: #683678; text-align: left; font-weight: bold;">Tenggat : <?php echo e(Carbon\Carbon::parse($dataInfo->tenggat)->isoFormat('D MMMM YYYY [Jam ] HH:mm')); ?></p>
                            </div>
                            <div class="row align-items-center">
                            <p class="text-sm" style="font-size: 15px; color: #8e5f9d; text-align: left; margin-top:8px;">Detail : <br> <?php
                                $text = $dataInfo->detail;
                                $text_with_links = preg_replace("/(https?:\/\/[^\s]+)/", '<a href="$1" style="font-size: 15px; color: #7145c6; text-align: left; margin-top:8px;" target="_blank">$1</a>', $text);

                                echo "$text_with_links";
                                ?> 
                        </p>                    
                    </div>
                            
                            <div class="row align-items-center">
                        <p class="text-sm" style="font-size: 15px; color: #683678; text-align: left; margin-top:8px; font-weight: bold;">File : </p>
                       </div>
                            <?php $__currentLoopData = $latsolF; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                            <div class="row mt-3 shop-cart-top" style="background: #0d0310; padding: 8px;">
                            
                                <div class="col" style="align-self: center;">                                
                                <div style="display: flex; align-items: center;">                            
                                    <p class="text-sm" style="font-size: 15px; color: #372243; font-weight: bold;"><?php echo e(Str::after($duta->file, '_')); ?></p>
                                </div>
                                </div>
                            
                                <div class="col" style="align-self: center;">
                                <div class="float-right" style="display: flex; align-items: center;">
                                    <a href="<?php echo e(route('downloadLat', ['id' => $duta->id])); ?>" style="margin-right: 14px;">
                                        <img src="<?php echo e(asset('img/download.png')); ?>" style="width: 32px;" alt="image">
                                    </a>
                                    <a href="<?php echo e(route('viewLat', ['id' => $duta->id])); ?>" target="__blank">
                                        <img src="<?php echo e(asset('img/external-link.png')); ?>" style="width: 22px;" alt="image">
                                    </a>                             
                                    
                                </div>
                                </div>
                            </div>          
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                        </div>
                    </div>


                        <div class="shop-cart-top" id="menilai" style="background-color: #14051d;">
                        <form class="form-horizontal" action="<?php echo e(route('nilaiSub')); ?>" method="post"
                        enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                            <div class="row" style="height: auto;">                            
                                <div class="col-lg-3">
                                <div class="single-input">
                                            <p id="nama">Pilih Siswa</p>
                                            <input class="text-sm" type="text" id="id" style="visibility: hidden; position: absolute;"
                                                name="id">
                                        </div>
                                </div>
                                <div class="col-lg-9">
                                    <div class="row">
                                        <div class="col-md-8">
                                        <input class="text-sm" type="text" placeholder="Beri nilai" id="nilai"
                                                style="background: #0d0310;color: #757575; border: 1px solid #81407d;border-radius: 5px; height: 55px;"
                                                name="nilai">

                                        </div>
                                        <div class="col-md-4">
                                            <button type="submit" class="cmn-btn btn-sm float-right" style="color: #fff; margin-top: 5px; font-size: 14px;"> 
                                                <i class="fas fa-add"></i>simpan
                                            </button>
                                        </div>
                                    </div>
                                </div>                             

                            </div>
                            </form>
                        </div>
                        
                        <?php echo $__env->make('layouts.alert-flash-message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="table-responsive" >
                            <table class="table">
                                <thead style="background-color: #0d0310;">
                                    <tr>
                                        <th scope="col" style="width: 15%">Nama</th>
                                        <th scope="col">Tanggal</th>
                                        <th scope="col">File</th>
                                        <th scope="col">Nilai</th>
                                        <th scope="col">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody id="tableBody" style="background-color: #14051d;">
                                <?php $__currentLoopData = $submisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row">
                                        <?php if(!empty($data->foto)): ?>
                                            <img src="<?php echo e(asset('storage/foto/' . $data->foto)); ?>" class="avatar-img rounded-circle" style="object-fit: cover; object-position: center top; width: 50px; height: 50px; margin: 5px;">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('img/user.png')); ?>" class="avatar-img rounded-circle" style="object-fit: cover; object-position: center top; width: 60px; height: 60px; margin-right: 5px;">
                                        <?php endif; ?>
                                        <span><?php echo e($data->nama); ?></span>
                                        </th>
                                        <td><?php echo e($data->tenggat); ?></td>
                                        <td><i class="fas fa-file-pdf"></i><span style="margin-left:5px; margin-right:5px;"><a href="<?php echo e(route('tampilSubmisi', ['id' => $data->submisi_id])); ?>" target="_blank" style="font-size: 14px;"><?php echo e(Str::after($data->lampiran, '_')); ?></a></span><i class="fas fa-external-link-alt"></i></td>
                                        <td><?php echo e($data->nilai); ?></td>
                                        <td> 
                                            <button type="button" id="edit-btn" class="cmn-btn btn-sm edit-btn" style="color: #fff; margin-top: 5px; font-size: 14px;" data-id="<?php echo e($data->submisi_id); ?>" data-nama="<?php echo e($data->nama); ?>" data-nilai="<?php echo e($data->nilai); ?>"> 
                                                nilai
                                            </button>                                 
                                        </td>
                                    </tr>      
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $submisis2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr >
                                        <th scope="row">
                                        <?php if(!empty($data->foto)): ?>
                                            <img src="<?php echo e(asset('storage/foto/' . $data->foto)); ?>" class="avatar-img rounded-circle" style="object-fit: cover; object-position: center top; width: 50px; height: 50px; margin: 5px; opacity: 0.5; mix-blend-mode: luminosity;">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('img/user2.png')); ?>" class="avatar-img rounded-circle" style="object-fit: cover; object-position: center top; width: 60px; height: 60px; margin-right: 5px;">
                                        <?php endif; ?>
                                        <span style="color: #626262;"><?php echo e($data->nama); ?></span>
                                        </th>
                                        <td style="color: #626262;">-</td>
                                        <td style="color: #626262;">-</td>
                                        <td style="color: #626262;">-</td>
                                        <td style="color: #626262;">-                            
                                        </td>
                                    </tr>      
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    
                        <div class="payment-container">
                        <div class="row">
                            <div class="col">
                                <button type="button" id="prevBtn" class="cmn-btn btn-sm float-left"
                                    style="color: #fff; margin-top: 0px;" onclick="prevRow()">Sebelumnya</button>
                            </div>
                            <div class="col" style="text-align: right;">
                                <button type="button" id="nextBtn" class="cmn-btn btn-sm float-right"
                                    style="color: #fff; margin-top: 0px;" onclick="nextRow()">Selanjutnya</button>
                            </div>
                        </div>
                        </div>
                    </div>

                    

                </div>
                </div>
            </div>
        </div>

    </section>

    <script>
$(document).ready(function() {
  $('.edit-btn').click(function() {
    var id = $(this).data('id');
    var nama =  $(this).data('nama');
    var nilai =  $(this).data('nilai');
    document.getElementById('nama').style.color = '#fff';
    document.getElementById('nilai').style.color = '#fff';


    $('#id').val(id);
    $('#nama').text(nama);
    $('#nilai').val(nilai);

    $('#menilai').css('box-shadow', '0 0 10px 5px rgb(202 0 255 / 50%)').fadeIn();
  });
});
</script>


<script>
    var currentRow = 0;
    var rowsPerPage = 4;
    var maxRows = document.querySelectorAll("#tableBody tr").length;

    function showCurrentRows() {
        var rows = document.querySelectorAll("#tableBody tr");
        var startIndex = currentRow * rowsPerPage;
        var endIndex = Math.min(startIndex + rowsPerPage, maxRows);
        rows.forEach(function(row, index) {
            if (index >= startIndex && index < endIndex) {
                row.style.display = "table-row";
            } else {
                row.style.display = "none";
            }
        });
    }

    function prevRow() {
        currentRow = Math.max(0, currentRow - 1);
        showCurrentRows();
        toggleButtons();
    }

    function nextRow() {
        currentRow = Math.min(Math.ceil(maxRows / rowsPerPage) - 1, currentRow + 1);
        showCurrentRows();
        toggleButtons();
    }

    function toggleButtons() {
        if (currentRow === 0) {
            document.getElementById('prevBtn').style.display = 'none';
        } else {
            document.getElementById('prevBtn').style.display = 'block';
        }

        if (currentRow === Math.ceil(maxRows / rowsPerPage) - 1) {
            document.getElementById('nextBtn').style.display = 'none';
        } else {
            document.getElementById('nextBtn').style.display = 'block';
        }
    }
    showCurrentRows();
    toggleButtons();
</script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('guru.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\DELL\Pictures\Laporan Akhir\Darul_Ulum\resources\views/guru/datanilai.blade.php ENDPATH**/ ?>