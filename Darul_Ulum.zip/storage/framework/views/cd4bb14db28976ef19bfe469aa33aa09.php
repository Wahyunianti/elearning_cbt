<script>
	$(function () {
		let loadingAlert = $('.modal-body #loading-alert');

		$('#datatable').DataTable({
			processing: true,
			serverSide: true,
			ajax: "<?php echo e(route('dataUsers')); ?>",
			columns: [
				{ data: 'DT_RowIndex', name: 'DT_RowIndex' },
				{ data: 'nama', name: 'nama' },
				{ data: 'action', name: 'action' },
			]
		});

		$('#datatable').on('click', '.bagian-edit', function () {
			loadingAlert.show();

			let id = $(this).data('id');

			let formActionURL = "<?php echo e(route('createUser', ':param')); ?>";
			formActionURL = formActionURL.replace(':param', id)

			let editBagianModalEveryInput = $('#editBagianModal :input').not('button[type=button], input[name=_token], input[name=_method]')
				.each(function () {
					$(this).not('select').val('Sedang mengambil data..');
					$(this).prop('disabled', true);
				});

			$.ajax({
				url: url,
				headers: {
					'Authorization': 'Bearer ' + localStorage.getItem('token'),
					'Accept': 'application/json',
				},
				success: function (response) {
					loadingAlert.slideUp();


					$('#editBagianModal #edit-bagian-form').attr('action', formActionURL);
					$('#editBagianModal #nama').val(response.data.nama);
				}
			});
		});
	});
</script>
<?php /**PATH C:\Users\DELL\Pictures\Laporan Akhir\Darul_Ulum\resources\views/guru/script.blade.php ENDPATH**/ ?>