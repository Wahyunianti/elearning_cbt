<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="theme-color" content="#0C041C">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Darul Ulum - Media Pembelajaran Bahasa Arab</title>

    <link rel="icon" href="<?php echo e(asset('img/baru.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="<?php echo e(asset('img/logo.png')); ?>" type="image/x-icon">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/magnific-popup.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/nice-select.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>


</head>

<body>

    <!-- start preloader -->
    <div class="preloader" id="preloader"></div>

    <!-- header-section start -->
    <!-- header-section end -->



    <div class="container page__container">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="/">Home</a></li>
            <li class="breadcrumb-item">Student</li>
            <li class="breadcrumb-item active">Add</li>
        </ol>
    
        <h1 class="h2">Quiz Results</h1>
    
        <div class="card card-body">
            <div class="row">
                <div class="col-lg-4 mr-5 ml-5">
                    <h4 class="card-title">Result Summary</h4>
                    <p>Answered Questions: <?php echo e($result->questions->count() - $result->unAnswered); ?></p>
                    <p>Unanswered Questions: <?php echo e($result->unAnswered); ?></p>
                    <p class="is-valid" style="color: green">Correct Answers: <?php echo e($result->correct); ?></p>
                    <p class="is-invalid" style="color: red">Incorrect Answers: <?php echo e($result->incorrect); ?></p>
                    <p>Total Questions: <?php echo e($result->questions->count()); ?></p>

                    <h3>Score: <?php echo e($result->correct); ?>/<?php echo e($result->questions->count()); ?></h3>
                </div>
                <div class="col-lg-6 d-flex align-items-center">
                    <form onsubmit="return false">
                        
                                 <?php $__currentLoopData = $result->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     
                                 <div class="question q<?php echo e(++$loop->index); ?>">
                                       
                                     <div class="card-header">
                                         <div class="media align-items-center">
                                             <div class="media-left">
                                                 <h4 class="mb-0"><strong>#<?php echo e($loop->index); ?></strong></h4>
                                             </div>
                                             <div class="media-body">
                                                 <h4 class="card-title">
                                                     <?php echo e($question->question); ?>

                                                 </h4>
                                             </div>
                                         </div>
                                     </div>
                         
                                     <div class="card-body">
                         
                                         <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                                         <div class="form-group">
                                             <div class="custom-control custom-checkbox">
                                                 <input id="<?php echo e($option); ?>"
                                                        type="checkbox"
                                                        name="<?php echo e($question->id); ?>"
                                                        <?php if($key == $question->choosedAnswer): ?>
                                                            <?php if(true): echo 'checked'; endif; ?>
                                                        <?php endif; ?>
                                                        class="custom-control-input 
                                                        <?php if($question->correct AND $key == $question->correctOption): ?>
                                                            <?php echo e("is-valid"); ?>

                                                        <?php endif; ?>
                                                        <?php if(!$question->correct AND $key == $question->correctOption): ?>
                                                            <?php echo e("is-invalid"); ?>

                                                        <?php endif; ?>
                                                        "
                                                        >
                                                 <label for=""
                                                        class="custom-control-label">(<?php echo e(Str::lower($key)); ?>) <?php echo e($option); ?></label>
                                             </div>
                                         </div>
                                             
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     </div>
                                 
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                              
                            </div>
                       </form>
            </div>
        <form action="" method="POST">
        
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-primary btn-pill float-left">Finish</button></form>

        </div>
    </div>




    <!-- footer-section start -->


    <!-- footer-section end -->

    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/slick.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.nice-select.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/fontawesome.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/wow.js')); ?>"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>
</body>

</html><?php /**PATH C:\Users\DELL\Pictures\Laporan Akhir\Darul_Ulum\resources\views/siswa/resultkuis.blade.php ENDPATH**/ ?>