<?php

namespace App\Models\utility;

class Pertanyaan
{
    public int $id;
    public int $soal;
    public string $jawaban;

}