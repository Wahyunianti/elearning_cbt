<?php

namespace App\Models\utility;

class Quiz 
{
    public int $id;
    public string $nama;
    public int $bab;
    public string $date;
    public int $duration;
}