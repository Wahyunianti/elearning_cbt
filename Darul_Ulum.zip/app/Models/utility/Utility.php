<?php

namespace App\Models\utility;

use Illuminate\Support\Collection;

class Utility
{


    public static Collection $currentQuestion;

}
